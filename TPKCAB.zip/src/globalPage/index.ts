import { mergeRouters } from "../trpcServer";

export const globalPageRoute = mergeRouters();
