import { mergeRouters } from "../trpcServer";

export const adminRouter = mergeRouters();
