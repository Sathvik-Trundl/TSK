import { router } from "@forge/bridge";
import NoLicenseImg from "@components/svgs/noLicense.png";

const NoLicense = () => {
  return (
    <div className="w-screen h-screen flex justify-center items-center flex-col gap-4">
      <img src={NoLicenseImg} alt="No License" width={200} height={200} />
      <div className="text-2xl">You don't have valid license for this app</div>
      <div className="text-xl">
        Please visit this{" "}
        <button
          className="text-ad-blue-400 hover:underline hover:text-ad-blue-500"
          onClick={() =>
            router.open(
              "https://marketplace.atlassian.com/plugins/trundl.apps.spm"
            )
          }
        >
          link
        </button>{" "}
        to get access
      </div>
    </div>
  );
};

export default NoLicense;
